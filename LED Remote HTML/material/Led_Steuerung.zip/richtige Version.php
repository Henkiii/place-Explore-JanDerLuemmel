﻿<html>
 <head>
  <title>LED Steuerung</title>               
 </head>
 <body>

<form action="index.php" method="post">
	<input type="submit" name="blue" value="blue">
	<br>
	<input type="submit" name="red" value="red">
	<br>
	<input type="submit" name="orange" value="orange">

</form>

 </body>
</html>



<?php

// Funciones PHP del pin GPIO 17

if ($_POST[blue]) { 
	   $a- exec("python3 /var/www/LED_Steuerung/Python_scripts/blue.py");
		}
if ($_POST[red]) { 
	   $a- exec("python3 /var/www/LED_Steuerung/Python_scripts/red.py");
		}
if ($_POST[orange]) { 
	   $a- exec("python3 /var/www/LED_Steuerung/Python_scripts/orange.py");
		}
?>
