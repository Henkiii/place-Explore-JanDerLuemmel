<html>
 <head>

<!--meta-->
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width">
<!--stylesheets-->
     <link rel="stylesheet" type="text/css" href="main.css">
     <link rel="stylesheet" type="text/css" href="stylesheet_red.css">
<!--icons etc-->
     <link rel="apple-touch-icon-precomposed" sizes="57x57" href="appleicon57x57.png" />
     <link rel="icon" type="image/x-icon" href="Raspberry.ico">
<!--title -->
     <title>LED Steuerung</title>
     
 </head>



 <body>

<div id="menu">

<div id="off">
     <img src="off.png" width="60px" height="60px">
     
     </div>
<div id="offlink">
	<form action="red.php" method="post">
		<input type="submit" name="turnoff" value="turnoff">	
</div>
<div id="back">
     <img src="pfeil.png" width="60px" height="60px">
     </div>
<div id="backlink">
    <a href="index.php" id="backlinktextfeld"></a>	
</div>        
<a id="mainmenubutton" href="index.php">Main Menu</a>
     
</div>
<div id="inhalt"> 

<div id="line1"></div>     
<div id="Red" class="buttons">
	<form action="red.php" method="post">
		<input type="submit" name="Red" value="Red">	

</div>
<div id="line2" class="line90"></div>
<div id="Orange" class="buttons">
	<form action="red.php" method="post">
		<input type="submit" name="Orange" value="Orange">	

</div>
<div id="line2" class="line90"></div>
<div id="Light-Orange" class="buttons">
	<form action="red.php" method="post">
		<input type="submit" name="LightOrange" value="Light-Orange">	

</div>
<div id="line2" class="line90"></div>
<div id="Yellow" class="buttons">
	<form action="red.php" method="post">
		<input type="submit" name="Yellow" value="Yellow">	

</div>
    
    </div>

 </body>

</html>



<?php

if ($_POST[Red]) { 
	   $a- exec("python3 /var/www/LED_Steuerung/Python_scripts/red/red.py");
		}
if ($_POST[Orange]) { 
	   $a- exec("python3 /var/www/LED_Steuerung/Python_scripts/red/orange.py");
		}
if ($_POST[LightOrange]) { 
	   $a- exec("python3 /var/www/LED_Steuerung/Python_scripts/red/light-orange.py");
		}
if ($_POST[Yellow]) { 
	   $a- exec("python3 /var/www/LED_Steuerung/Python_scripts/red/yellow.py");
		}
if ($_POST[turnoff]) { 
	   $a- exec("python3 /var/www/LED_Steuerung/Python_scripts/off.py");
		}
?>
