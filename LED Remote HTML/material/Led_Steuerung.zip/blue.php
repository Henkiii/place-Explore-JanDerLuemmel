<html>
 <head>

<!--meta-->
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width">
<!--stylesheets-->
     <link rel="stylesheet" type="text/css" href="main.css">
     <link rel="stylesheet" type="text/css" href="stylesheet_blue.css">
<!--icons etc-->
     <link rel="apple-touch-icon-precomposed" sizes="57x57" href="appleicon57x57.png" />
     <link rel="icon" type="image/x-icon" href="Raspberry.ico">
<!--title -->
     <title>LED Steuerung</title>
     
 </head>



 <body>

     
<div id="menu">

<div id="off">
     <img src="off.png" width="60px" height="60px">
     
     </div>
<div id="offlink">
	<form action="blue.php" method="post">
		<input type="submit" name="turnoff" value="turnoff">	
</div>
<div id="back">
     <img src="pfeil.png" width="60px" height="60px">
     </div>
<div id="backlink">
    <a href="index.php" id="backlinktextfeld"></a>	
</div>       
<a id="mainmenubutton" href="index.php">Main Menu</a>
     
</div>
<div id="inhalt">     

<div id="line1"></div>     
<div id="Blue" class="buttons">
	<form action="blue.php" method="post">
		<input type="submit" name="Blue" value="Blue">	

</div>
<div id="line2" class="line90"></div>
<div id="Smooth-Blue" class="buttons">
	<form action="blue.php" method="post">
		<input type="submit" name="SmoothBlue" value="Smooth-Blue">	

</div>
<div id="line2" class="line90"></div>
<div id="Lila" class="buttons">
	<form action="blue.php" method="post">
		<input type="submit" name="Lila" value="Lila">	

</div>
<div id="line2" class="line90"></div>
<div id="Pink" class="buttons">
	<form action="blue.php" method="post">
		<input type="submit" name="Pink" value="Pink">	

</div>

    </div>
    
</body>

</html>


<?php

// Funciones PHP del pin GPIO 17

if ($_POST[Blue]) { 
	   $a- exec("python3 /var/www/LED_Steuerung/Python_scripts/blue/blue.py");
		}
if ($_POST[SmoothBlue]) { 
	   $a- exec("python3 /var/www/LED_Steuerung/Python_scripts/blue/smoothblue.py");
		}
if ($_POST[Lila]) { 
	   $a- exec("python3 /var/www/LED_Steuerung/Python_scripts/blue/lila.py");
		}
if ($_POST[Pink]) { 
	   $a- exec("python3 /var/www/LED_Steuerung/Python_scripts/blue/pink.py");
		}
if ($_POST[turnoff]) { 
	   $a- exec("python3 /var/www/LED_Steuerung/Python_scripts/off.py");
		}
?>
