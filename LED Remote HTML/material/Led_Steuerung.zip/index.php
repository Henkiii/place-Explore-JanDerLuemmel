
<html>
 <head>

     <meta charset="UTF-8">
     <meta name="viewport" content="width=device-width">
     
     <link rel="stylesheet" type="text/css" href="main.css">
     <link rel="stylesheet" type="text/css" href="stylesheet.css">
     <link rel="apple-touch-icon-precomposed" sizes="57x57" href="appleicon57x57.png" />
     <link rel="icon" type="image/x-icon" href="Raspberry.ico">

     <title>LED Steuerung</title>
     
          
 </head>



 <body>

<!--MENU-->     
<div id="menu">

<div id="off">
     <img src="off.png" width="60px" height="60px">
     
     </div>
<div id="offlink">
	<form action="index.php" method="post">
		<input type="submit" name="turnoff" value="turnoff">	
</div>
<div id="back">
     <img src="pfeil.png" width="60px" height="60px">
     
     </div>
<div id="backlink">
	<form action="index.php" method="post">
		<input type="submit" name="back" value="back">	
</div>     
<a id="mainmenubutton" href="index.html">Main Menu</a>
     
</div>
<!--INHALT-->
<div id="inhalt"> 
    
<div id="line1"></div>     
<div id="Red" class="buttons"><a href="red.php">Red</a></div>
<div id="line2" class="line90"></div>
<div id="Green" class="buttons"><a href="green.php">Green</a></div>
<div id="line2" class="line90"></div>
<div id="Blue" class="buttons"><a href="blue.php">Blue</a></div>
<div id="line2" class="line90"></div>
<div id="White" class="buttons"><a href="white.php">White</a></div>

</div> 

 </body>
</html>

    
    
<?php

// Funciones PHP del pin GPIO 17

if ($_POST[turnoff]) { 
	   $a- exec("python3 /var/www/LED_Steuerung/Python_scripts/off.py");
		}

?>