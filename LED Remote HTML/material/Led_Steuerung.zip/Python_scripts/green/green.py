#!/pi/bin/python3

import pigpio

pi = pigpio.pi()

red = 23
green = 22
blue = 24

def RGB(r,g,b):
    pi.set_PWM_dutycycle(red,r)
    pi.set_PWM_dutycycle(green,g)
    pi.set_PWM_dutycycle(blue,b)

RGB(0,255, 0)
