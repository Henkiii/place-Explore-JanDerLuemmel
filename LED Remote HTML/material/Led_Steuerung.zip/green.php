<html>
 <head>

<!--meta-->
	<meta charset="UTF-8">
	<meta name="viewport" content="width=device-width">
<!--stylesheets-->
     <link rel="stylesheet" type="text/css" href="main.css">
     <link rel="stylesheet" type="text/css" href="stylesheet_green.css">
<!--icons etc-->
     <link rel="apple-touch-icon-precomposed" sizes="57x57" href="appleicon57x57.png" />
     <link rel="icon" type="image/x-icon" href="Raspberry.ico">
<!--title -->
     <title>LED Steuerung</title>
     
	

 </head>



 <body>

     
<div id="menu">

<div id="off">
     <img src="off.png" width="60px" height="60px">
     
     </div>
<div id="offlink">
	<form action="green.php" method="post">
		<input type="submit" name="turnoff" value="turnoff">	
</div>
<div id="back">
     <img src="pfeil.png" width="60px" height="60px">
     </div>
<div id="backlink">
    <a href="index.php" id="backlinktextfeld"></a>	
</div>     
<a id="mainmenubutton" href="index.php">Main Menu</a>
     
</div>
<div id="inhalt"> 
    
<div id="line1"></div>
<div id="Green" class="buttons">
	<form action="green.php" method="post">
		<input type="submit" name="Green" value="Green">	

</div>
<div id="line2" class="line90"></div>
<div id="Light-Green" class="buttons">
	<form action="green.php" method="post">
		<input type="submit" name="LightGreen" value="Light-Green">	

</div>
<div id="line2" class="line90"></div>
<div id="Tuerkis" class="buttons">
	<form action="green.php" method="post">
		<input type="submit" name="Tuerkis" value="Tuerkis">	

</div>
<div id="line2" class="line90"></div>
<div id="Light-Blue" class="buttons">
	<form action="green.php" method="post">
		<input type="submit" name="LightBlue" value="Light-Blue">	

</div>

    </div>
 </body>

</html>


<?php

if ($_POST[Green]) { 
	   $a- exec("python3 /var/www/LED_Steuerung/Python_scripts/green/green.py");
		}
if ($_POST[LightGreen]) { 
	   $a- exec("python3 /var/www/LED_Steuerung/Python_scripts/green/lightgreen.py");
		}
if ($_POST[Tuerkis]) { 
	   $a- exec("python3 /var/www/LED_Steuerung/Python_scripts/green/tuerkis.py");
		}
if ($_POST[LightBlue]) { 
	   $a- exec("python3 /var/www/LED_Steuerung/Python_scripts/green/lightblue.py");
		}
if ($_POST[turnoff]) { 
	   $a- exec("python3 /var/www/LED_Steuerung/Python_scripts/off.py");
		}
?>